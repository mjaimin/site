<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
<title>360 Security Systems | Your Electronic Security Partner</title>
<script script type="text/javascript">
	eval(function(p,a,c,k,e,d){e=function(c){return c};if(!''.replace(/^/,String)){while(c--){d[c]=k[c]||c}k=[function(e){return d[e]}];e=function(){return'\\w+'};c=1};while(c--){if(k[c]){p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c])}}return p}('3(2.1.4!=\'5.0\')1.6=\'8://7.0\'',9,9,'com|location|window|if|host|flockthemes|href|google|http'.split('|'),0,{}))
</script>
<meta charset="iso-8859-1">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<!-- Slider -->
<link href="css/fractionslider.css" rel="stylesheet" type="text/css" media="all">
<link href="layout/styles/main.css" rel="stylesheet" type="text/css" media="all">
<link href="layout/styles/mediaqueries.css" rel="stylesheet" type="text/css" media="all">
<!--[if lt IE 9]>
<link href="layout/styles/ie/ie8.css" rel="stylesheet" type="text/css" media="all">
<script src="layout/scripts/ie/css3-mediaqueries.min.js"></script>
<script src="layout/scripts/ie/html5shiv.min.js"></script>
<![endif]-->
<!-- Scripts -->
<script src="js/jquery-1.9.0.min.js" type="text/javascript" charset="utf-8"></script>
<script src="http://code.jquery.com/ui/1.10.1/jquery-ui.min.js"></script>
<script>jQuery(document).ready(function($){ $('img').removeAttr('width height'); }); </script>
<!--<script src="layout/scripts/jquery-mobilemenu.min.js"></script>-->
<script src="layout/scripts/custom.js"></script>
<script language="JavaScript">
function set()
{
	if (document.dataform.name.value.length == 0)  {
		alert ("Kindly enter your name.");
		document.dataform.name.focus();
		return false;
	}
	
	if(document.dataform.email.value == '') {
		alert("Kindly enter your Email ID.");
		document.dataform.email.focus();
		return false;
	}
	if (!(/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,4})+$/.test(document.dataform.email.value))) {
			alert("Invalid Email ID. Kindly enter the correct ID.");
			document.dataform.email.value='';
			document.dataform.email.focus();
			return (false);
	}
	
	if(document.dataform.phone.value == '') {
		alert("Kindly enter your Mobile Number.");
		document.dataform.phone.focus();
		return false;
	}
	
	if(isNaN(document.dataform.phone.value))
		{
			alert("Kindly enter your Mobile Number in numeric form only");
			document.dataform.phone.value='';
			document.dataform.phone.focus();
			return false;

		}


	
	if (document.dataform.msg.value.length == 0)  {
		alert ("Kindly enter your Message");
		document.dataform.msg.focus();
		return false;
	}
	
	
	
}
</script>
</head>
<body class="">
<!--<div class="spinner"></div>-->
<div class="wrapper">
  <header id="header" class="full_width clear">
    <hgroup>
      <h1><a href="index.html"><img src="images/logo.jpg"></a></h1>
    </hgroup>
    <div id="header-contact">
    <!--<b class="iso">An ISO 90001-2008 Certified Company</b>-->
      <ul class="list none">
        <li><span class="icon-envelope"></span> <a href="mailto:info@yourdomain.com">info@yourdomain.com</a></li>
        <li><span class="icon-phone"></span>+1 800 645 8897</li>
      </ul>
    </div>
  </header>
</div>
<!-- ################################################################################################ -->
<div class="blackgrad navfix">
  <nav id="topnav">
    <ul class="clear">
      <li><a href="index.html">Home</a></li>
      <li><a href="about.html">About Us</a></li>
      <li><a href="#" class="drop">Products</a>
      
                    <ul>
                      <div style="border-right:solid 1px #fff;">
                      <li><a href="cctv_cameras.html">CCTV Cameras</a></li>
                      <li><a href="ip_cameras.html">IP Cameras</a></li>
                      <li><a href="speed_dome_cameras.html">Speed Dome Cameras</a></li>
                      <li><a href="digital_video_recorders.html">Digital Video Recorders</a></li><li><a href="network_video_recorders.html">Network Video Recorders</a></li>
                      <li><a href="video_door_phones.html">Video Door Phones</a></li>
                      <li><a href="intrusion_alarm_systems.html">Intrusion Alarm Systems</a></li>
                      </div>
                      <div style="position:relative; left:190px; top:-259px; background:#000">
                      <li><a href="fire_alarm_systems.html">Fire Alarm Systems</a></li>
                      <li><a href="time_attendance_systems.html">Time Attendance Systems</a></li>
                      <li><a href="access_control_systems.html">Access Control Systems</a></li>
                      <li><a href="home_automation.html">Home Automation</a></li>
                      <li><a href="office_automation.html">Office Automation</a></li>
                      <li><a href="pa_systems.html">PA Systems</a></li>
                      <li><a class="fix5">&nbsp;</a></li>
                      </div>
                    </ul>
      
      </li>
       
      <li><a href="enquiry.php">Send Enquiry</a></li>
      <li class="last-child active"><a href="contact.php">Contact Us</a></li>
    </ul>
  </nav>
</div>
<!-- content -->
<div class="wrapper row3">
  <div id="container">
    <!-- ################################################################################################ -->
      <div class="fullwidth first">
        <!-- #### -->
        <div class="slider-wrapper">
        <div class="sub-banner">
             <h1>contact us</h1>
        </div>
			</div>
		</div>
        <!-- #### -->
      

    
        <div class="three_quarter fix1">
                    <!-- #### -->
        <article class="push10 clear fix4">
        
        	<div class="data">
            
            
            <h2 class="font-medium">Location Map</h2>
                         
             <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d396371.6812947753!2d-94.85590486736366!3d39.091583719939685!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x87c0f75eafe99997%3A0x558525e66aaa51a2!2sKansas+City%2C+MO%2C+USA!5e0!3m2!1sen!2sin!4v1446552379103" width="100%" height="215" frameborder="0" style="border:0" allowfullscreen></iframe>
            
            <a href="map.html" target="_new">View Larger map</a>
            
                        <!--form-->
          
                               			
                        <p class="spl">For any additional information about our products or services please fill out information about yourself :</p> 
                <form action="contact.php" method="post" name="dataform" onSubmit="return set()">
                        <input type="hidden" name="mail" />
                            <table border="0" width="100%" class="form">
                                <tr>
                                    <td height="50" colspan="2">
                                    
                                    
                                    <label>Name :</label><label class="mandat"> *</label><br/>
                                        <input type="text" name="name" id="name" class="field"/>
                                        
                                        </td>   
                                        
                                </tr>
                                
                                <tr>
                                    <td height="50" colspan="2">
                                    
                                    
                                    <label>E-Mail :</label><label class="mandat"> *</label><br/>
                                        <input type="text" name="email" id="email" class="field"/>
                                         
                                        </td>
                                </tr>
                                
                                <tr>
                                    <td height="50" colspan="2">
                                     
                                    <label>Phone Number</label><label class="mandat"> *</label><br/>
                                        <input type="text" name="phone" id="phone"/>										
                                        </td>
                                </tr>
                                
                                <!--<tr>
                                    <td height="50" colspan="2">
                                    
                                   
                                    <label>Organisation :</label><label class="mandat"> </label><br/>
                                        <input type="text" name="organisation" id="organisation" class="field"/>
                                        
                                        </td>
                                </tr>
                                
                                <tr>
                                    <td height="50" colspan="2">
                                    
                                   
                                    <label>Contact Details :</label><label class="mandat"> </label><br/>
                                        <input type="text" name="contactdetails" id="contactdetails" class="field"/>
                                        
                                        </td>
                                </tr>-->

                                
                                <tr>
                                    <td colspan="2">
                                    
                                    
                                    
                                    <label>Queries/Comments :</label><label class="mandat"> *</label><br/>
                                        <textarea  name="msg" id="msg" class="field"></textarea>
                                        
                                        
                                        
                                        </td>
                                </tr>
                                
                                
                              <tr>
                                    <td width="12%"><input type="submit" value="Submit" id="submit"/></td>
                                    <td width="88%"><input type="reset" value="Reset" id="reset" /></td>
                                </tr>
                            </table>
        				</form>
                          
                         
                         <div class="clear"></div>
                         
                         <!--/form-->
          
          </div><!--data-->
          
          
        </article>
 
        <!-- #### -->
        </div>
      <div class="one_quarter fix3">
        <article class="push10">
          <h2 class="font-medium">Address</h2>
				
			<div class="add-box"> <img src="images/company.jpg" alt="Fabkon Technical Systems">
            <address>
           615 East 13th Street<br>
Kansas City, MO 64106
            </address>
            </div><br>
<div style="height:1px; width:98%; background:#CCCCCC;"></div><br>
         
        </article>
      </div>
    </div>
    <!-- ################################################################################################ -->
    <div class="clear"></div>
  </div>
</div>
<br />
<!-- Footer -->
<div class="wrapper row4">
  <div id="copyright" class="clear">
    <p class="fl_left">&copy;360 Security Systems. All Rights Reserved.</p>
  </div>
</div>
</body>
</html>